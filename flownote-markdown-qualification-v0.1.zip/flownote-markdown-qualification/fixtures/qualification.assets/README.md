# Qualification assets

Place a small PNG named `list-image.png` here before running the image-in-list test.
